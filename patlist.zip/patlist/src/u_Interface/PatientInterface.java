package u_Interface;

import java.util.Scanner;

import myentities.Patient;

public class PatientInterface {

	public static void main(String[] args) {
		
		Patient patient = new Patient();
		Scanner sc=new Scanner(System.in);
		int pid,testn;
		String pname;
		System.out.println("Pid: ");
		pid=sc.nextInt();
		
		System.out.println("Patient Name: ");
		pname=sc.next();
		
		System.out.println("Number of Test: ");
		testn=sc.nextInt();
		
		
		int tid;
		String testname;
		double cost;
		patient.setPid(pid);
		patient.setPname(pname);
//		patient.setTestn(testn);
		while(testn>0)
		{
			System.out.println("Test id:");
			tid=sc.nextInt();
			System.out.println("Test Name:");
			testname=sc.next();
			System.out.println("Test Cost (Rs <500):");
			cost=sc.nextDouble();
			if(cost>=500)
			{
				patient.add(tid,testname,cost);
			}
			else
			{
				System.err.println("Cost must be greater than Rs. 500");
			}
			testn--;
		}
	
		patient.add();
	}

}
