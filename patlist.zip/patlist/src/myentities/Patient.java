package myentities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
//import java.util.ListIterator;

import dao.PatientDAO;
import dao.PatientDAOImpl;

public class Patient {
	
	
	PatientDAO pd = new PatientDAOImpl();
	int pid;
	String pname;
	double totalcost=0;
	public ArrayList<Medicaltest> am = new ArrayList<>();
	
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public void add(int tid, String testname, double cost) {
		
		am.add(new Medicaltest(tid,testname,cost));
		totalcost=cost+totalcost;
	}
	public void add(){
		
		pd.addToDatabase(pid,pname,totalcost);
		/*for (int i = 0; i < am.size(); i++) {
            Medicaltest value = am.get(i);
            System.out.println("Element: " + value);
        }*/
	}
	
		
}
	

	
	
	


