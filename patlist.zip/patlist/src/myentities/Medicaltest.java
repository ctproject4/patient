package myentities;

public class Medicaltest {
	
	
	private int tid;
	private String testname;
	private double cost;
//	public Medicaltest(){};
	public  Medicaltest(int tid, String testname, double cost) {
		super();
		this.tid = tid;
		this.testname = testname;
		this.cost = cost;
	}

	
	
	

}
