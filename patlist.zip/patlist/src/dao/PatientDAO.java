package dao;

public interface PatientDAO {
	
	void addToDatabase(int pid, String pname, double totalcost);

	
}
