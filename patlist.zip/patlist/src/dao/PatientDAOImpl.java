package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//import javax.swing.text.html.HTMLDocument.Iterator;

import myentities.Patient;

//import com.mysql.jdbc.PreparedStatement;

public class PatientDAOImpl implements PatientDAO{
//	Patient p = new Patient();
	Patient p = new Patient();
	@Override
	public void addToDatabase(int pid, String pname, double totalcost) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/abcd","root", "root");
			PreparedStatement ps;
			
			ps = con.prepareStatement("insert into bill values (?,?,?)");
			
			ps.setInt(1, pid);
			ps.setString(2, pname);
			ps.setDouble(3, totalcost);
			ps.executeUpdate();
			
		} 
		
		catch (Exception e1) {
			
	}

		  
		
}

	

}
